<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="1" tilewidth="16" tileheight="16" tilecount="1440" columns="30">
 <image source="../tilesets/1.png" width="480" height="768"/>
</tileset>
