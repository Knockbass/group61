<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="exterior" tilewidth="16" tileheight="16" tilecount="969" columns="17">
 <image source="../tilesets/exterior.png" width="272" height="912"/>
</tileset>
