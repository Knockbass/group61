<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="3" tilewidth="16" tileheight="16" tilecount="240" columns="30">
 <image source="../tilesets/3.png" width="480" height="128"/>
</tileset>
