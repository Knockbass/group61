<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="SRW_Marketplace_tileset_B" tilewidth="16" tileheight="16" tilecount="2304" columns="48">
 <image source="../tilesets/SRW_Marketplace_tileset_B.png" width="768" height="768"/>
</tileset>
