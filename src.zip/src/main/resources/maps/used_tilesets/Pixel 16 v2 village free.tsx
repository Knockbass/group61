<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Pixel 16 v2 village free" tilewidth="16" tileheight="16" tilecount="289" columns="17">
 <image source="../tilesets/Pixel 16 v2 village free.png" width="282" height="276"/>
</tileset>
