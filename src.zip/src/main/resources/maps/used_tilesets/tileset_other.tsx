<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="tileset_other" tilewidth="16" tileheight="16" tilecount="736" columns="23">
 <image source="../tilesets/tileset_other.png" width="368" height="512"/>
</tileset>
