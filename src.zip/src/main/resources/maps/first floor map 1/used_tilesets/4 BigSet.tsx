<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="4 BigSet" tilewidth="16" tileheight="16" tilecount="216" columns="8">
 <image source="../tilesets/4 BigSet.png" width="128" height="432"/>
</tileset>
