<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Carpets_1_16x16" tilewidth="16" tileheight="16" tilecount="486" columns="27">
 <image source="../tilesets/Carpets_1_16x16.png" width="432" height="288"/>
</tileset>
