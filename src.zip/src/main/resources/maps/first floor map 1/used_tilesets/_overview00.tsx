<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="_overview00" tilewidth="16" tileheight="16" tilecount="1952" columns="32">
 <image source="../tilesets/_overview00.png" width="512" height="976"/>
</tileset>
