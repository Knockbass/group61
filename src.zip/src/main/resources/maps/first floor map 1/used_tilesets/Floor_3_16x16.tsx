<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Floor_3_16x16" tilewidth="16" tileheight="16" tilecount="990" columns="22">
 <image source="../tilesets/Floor_3_16x16.png" width="360" height="720"/>
</tileset>
