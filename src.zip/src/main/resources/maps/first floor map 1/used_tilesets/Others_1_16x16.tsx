<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Others_1_16x16" tilewidth="16" tileheight="16" tilecount="1350" columns="30">
 <image source="../tilesets/Others_1_16x16.png" width="480" height="720"/>
</tileset>
