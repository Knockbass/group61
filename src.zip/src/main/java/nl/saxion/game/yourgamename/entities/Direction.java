package nl.saxion.game.yourgamename.entities;

public enum Direction {
    UP,
    DOWN,
    LEFT,
    RIGHT
}
